// ... existing code ... <applicationMutation definition>

const applicationMutation = useMutation({
  mutationFn: async (data: ApplicationFormValues) => {
    try {
      // Create FormData for file upload
      const formData = new FormData();
      formData.append('description', data.description);
      if (data.resumeFile) {
        formData.append('resumeFile', data.resumeFile);
      }

      // Make direct fetch call instead of using apiRequest to handle multipart/form-data
      const response = await fetch(`/api/jobs/${jobId}/applications`, {
        method: 'POST',
        credentials: 'include',
        body: formData,
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || 'Failed to submit application');
      }

      return response.json();
    } catch (error: any) {
      console.error('Application submission error:', error);
      throw new Error(error.message || 'An error occurred while submitting your application');
    }
  },
  onSuccess: () => {
    toast({
      title: 'Application Submitted',
      description: 'Your application has been submitted successfully.',
    });
    setApplicationDialogOpen(false);
    form.reset();
    // Refresh job applications data if needed
    queryClient.invalidateQueries({
      queryKey: [`/api/jobs/${jobId}/applications`],
    });
  },
  onError: (error: any) => {
    toast({
      title: 'Application Failed',
      description: error.message || 'Failed to submit application. Please try again.',
      variant: 'destructive',
    });
  },
});

const onApplicationSubmit = (data: ApplicationFormValues) => {
  if (!data.description) {
    toast({
      title: 'Missing Information',
      description: 'Please provide a description for your application.',
      variant: 'destructive',
    });
    return;
  }

  applicationMutation.mutate(data);
};

// ... existing code ... <rest of the component>
