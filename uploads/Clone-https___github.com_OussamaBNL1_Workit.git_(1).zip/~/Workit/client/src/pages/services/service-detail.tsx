// ... existing code ... <imports and other code>

  const handleOrderNow = () => {
    if (isVisitor) {
      setVisitorNotifyMessage({
        title: 'Order Unavailable in Visitor Mode',
        description: 'You need to sign up or log in to order services on WorkiT.'
      });
      setVisitorNotifyOpen(true);
      return;
    }

    if (!isAuthenticated) {
      toast({
        title: 'Authentication Required',
        description: 'Please log in to order this service.',
        variant: 'destructive',
      });
      setLocation('/auth/login');
      return;
    }

    if (user?.id === service.userId) {
      toast({
        title: 'Cannot Order',
        description: 'You cannot order your own service.',
        variant: 'destructive',
      });
      return;
    }

    // Navigate to payment page with service ID
    setLocation(`/payment?serviceId=${serviceId}`);
  };

// ... existing code ... <rest of the component>
