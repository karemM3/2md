// ... existing code ... <login route>

app.post('/api/auth/login', (req, res, next) => {
  try {
    loginSchema.parse(req.body);
    passport.authenticate('local', (err: any, user: any, info: any) => {
      if (err) {
        return next(err);
      }
      if (!user) {
        return res.status(401).json({ message: info.message || 'Authentication failed' });
      }
      req.login(user, (err) => {
        if (err) {
          return next(err);
        }
        // Return safe user without password
        const safeUser = { ...user };
        delete safeUser.password;
        return res.status(200).json(safeUser);
      });
    })(req, res, next);
  } catch (error: any) {
    res.status(400).json({ message: error.message || 'Invalid login data' });
  }
});

// ... existing code ... <job application submission route>

app.post('/api/jobs/:jobId/applications', authenticateUser, async (req, res) => {
  try {
    const jobId = req.params.jobId;
    const userId = req.user.id;

    // Check if job exists
    const job = await db.selectOne('job', { id: jobId }).catch(() => null);
    if (!job) {
      return res.status(404).json({ message: 'Job not found' });
    }

    // Check if user already applied
    const existingApplication = await db
      .selectOne('jobApplication', { jobId, userId })
      .catch(() => null);
    if (existingApplication) {
      return res.status(400).json({ message: 'You have already applied to this job' });
    }

    // Handle file upload if exists
    let resumeUrl = null;
    if (req.files && req.files.resumeFile) {
      const resumeFile = req.files.resumeFile as fileUpload.UploadedFile;
      const fileExt = path.extname(resumeFile.name);
      const fileName = `${uuidv4()}${fileExt}`;
      const filePath = path.join('uploads', 'resumes', fileName);

      // Ensure directory exists
      const uploadDir = path.join('uploads', 'resumes');
      if (!fs.existsSync(uploadDir)) {
        fs.mkdirSync(uploadDir, { recursive: true });
      }

      // Save file
      await resumeFile.mv(path.join(uploadDir, fileName));
      resumeUrl = `/uploads/resumes/${fileName}`;
    }

    // Create application
    const applicationData = {
      id: uuidv4(),
      userId,
      jobId,
      description: req.body.description,
      resumeUrl,
      status: 'pending',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    await db.insert('jobApplication', applicationData);

    res.status(201).json(applicationData);
  } catch (error: any) {
    console.error('Error submitting application:', error);
    res.status(500).json({ message: error.message || 'Failed to submit application' });
  }
});

// ... existing code ... <order creation route>

app.post('/api/services/:serviceId/orders', authenticateUser, async (req, res) => {
  try {
    const serviceId = req.params.serviceId;
    const userId = req.user.id;

    // Check if service exists
    const service = await db.selectOne('service', { id: serviceId }).catch(() => null);
    if (!service) {
      return res.status(404).json({ message: 'Service not found' });
    }

    // Validate request data against schema
    const validData = insertOrderSchema.parse({
      ...req.body,
      userId,
      serviceId,
      sellerId: service.userId,
    });

    // Create order in database
    const orderData = {
      id: uuidv4(),
      userId,
      serviceId,
      sellerId: service.userId,
      status: 'pending',
      paymentMethod: validData.paymentMethod || 'credit_card',
      price: service.price,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    await db.insert('order', orderData);

    // Send notification to seller
    // You would implement this in a real application

    res.status(201).json(orderData);
  } catch (error: any) {
    console.error('Error creating order:', error);
    res.status(500).json({ message: error.message || 'Failed to create order' });
  }
});

// ... existing code ... <rest of the routes>
